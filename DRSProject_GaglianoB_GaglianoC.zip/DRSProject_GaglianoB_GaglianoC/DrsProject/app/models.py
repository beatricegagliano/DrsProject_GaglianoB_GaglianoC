from django.db import models

# Create your models here.

class Utente(models.Model):
    name = models.CharField(max_length=200,default="null")
    surname = models.CharField(max_length=200,default="null")
    email=models.CharField(max_length=200,default="null")
    username=models.CharField(primary_key=True,max_length=200,unique=True)
    password = models.CharField(max_length=200,default="null")
    isAdmin=models.BooleanField(default=False)


class TipoRifiuto(models.Model):
    name=models.CharField(primary_key=True,max_length=200,unique=True)

class PuntoRaccolta(models.Model):
    name = models.CharField(primary_key=True,max_length=200,unique=True)
    address = models.CharField(max_length=200,default="null")

class Rifiuto(models.Model):
    cod_punto_raccolta=models.ForeignKey(PuntoRaccolta, on_delete=models.CASCADE)
    cod_tipo_rifiuto=models.ForeignKey(TipoRifiuto,on_delete=models.CASCADE)
    id_utente=models.ForeignKey(Utente,on_delete=models.CASCADE)

class PuntoControllo(models.Model):
    name = models.CharField(primary_key=True,max_length=200,unique=True)
    address = models.CharField(max_length=200,default="null")


class Segnalazione(models.Model):
    titolo=models.CharField(max_length=200,default="null")
    descrizione=models.CharField(max_length=200,default="null")
    importo=models.FloatField(null=True)
    cod_rifiuto=models.ForeignKey(Rifiuto,on_delete=models.CASCADE)
    cod_punto_controllo=models.ForeignKey(PuntoControllo,on_delete=models.CASCADE)
    id_addetto=models.ForeignKey(Utente,on_delete=models.CASCADE)