from rest_framework import viewsets, generics

from app.models import Utente, TipoRifiuto, PuntoRaccolta, Rifiuto, PuntoControllo, Segnalazione
from app.serializers import UtenteSerializer, TipoRifiutoSerializer, PuntoRaccoltaSerializer, RifiutoSerializer, \
    PuntoControlloSerializer, SegnalazioneSerializer


class UtenteViewSet(viewsets.ModelViewSet):
    """
    API endpoint per la visualizzazione, inserimento, modifica o rimozione degli utenti.
    """
    queryset = Utente.objects.all()
    serializer_class = UtenteSerializer



class TipoRifutoViewSet(viewsets.ModelViewSet):
    """
    API endpoint per la visualizzazione, inserimento, modifica o rimozione dei tipi di rifiuti.
    """

    queryset = TipoRifiuto.objects.all()
    serializer_class = TipoRifiutoSerializer

class PuntoRaccoltaViewSet(viewsets.ModelViewSet):
    """
    API endpoint per la visualizzazione,inserimento, modifica o rimozione dei punti di raccolta.
    """

    queryset = PuntoRaccolta.objects.all()
    serializer_class = PuntoRaccoltaSerializer

class RifiutoViewSet(viewsets.ModelViewSet):
    """
    API endpoint per la visualizzazione, inserimento, modifica o rimozione dei rifiuti.
    """

    queryset = Rifiuto.objects.all()
    serializer_class = RifiutoSerializer


class RifiutiList(generics.ListAPIView):
    serializer_class = RifiutoSerializer

    def get_queryset(self):
        """
        Questa vista ritorna una lista di rifiuti per
        l'utente come determinato dallo username dell'URL.
        """
        id_utente = self.kwargs['id_utente']
        return Rifiuto.objects.filter(id_utente=id_utente)

class PuntoControlloViewSet(viewsets.ModelViewSet):
    """
    API endpoint per la visualizzazione, inserimento, modifica o rimozione dei Punti di controllo.
    """
    queryset = PuntoControllo.objects.all()
    serializer_class = PuntoControlloSerializer

class SegnalazioneViewSet(viewsets.ModelViewSet):
    """
    API endpoint per la visualizzazione, inserimento, modifica o rimozione delle segnalazioni.
    """
    queryset = Segnalazione.objects.all()
    serializer_class = SegnalazioneSerializer

class SegnalazioniList1(generics.ListAPIView):
        serializer_class = SegnalazioneSerializer

        def get_queryset(self):
            """
            Questa vista ritorna una lista di segnalazioni per
            l'admnin come determinato dall' id_addetto dell'URL.
            """
            id_addetto = self.kwargs['id_addetto']
            return Segnalazione.objects.filter(id_addetto=id_addetto)