
from rest_framework import serializers

from app.models import Utente, TipoRifiuto, PuntoRaccolta, Rifiuto, PuntoControllo, Segnalazione


class UtenteSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = Utente
        fields = [
            'name',
            'surname',
            'email',
            'username',
            'password',
            'isAdmin'
        ]


class TipoRifiutoSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = TipoRifiuto
        fields = [
            'name',
            ]

class PuntoRaccoltaSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = PuntoRaccolta
        fields = [
            'name',
            'address',
            ]
class RifiutoSerializer(serializers.ModelSerializer):
    class Meta:
        model = Rifiuto
        fields = [
            'id',
            'cod_punto_raccolta',
            'cod_tipo_rifiuto',
            'id_utente',
            ]

class PuntoControlloSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = PuntoControllo
        fields = [
        'name',
        'address',
                ]


class SegnalazioneSerializer(serializers.ModelSerializer):
    class Meta:
        model = Segnalazione
        fields = [
            'id',
            'titolo',
            'descrizione',
            'importo',
            'cod_rifiuto',
            'cod_punto_controllo',
            'id_addetto',
        ]