"""
drs URL Configuration

"""
from django.conf.urls import url
from django.contrib import admin


from django.urls import include, path
from rest_framework import routers

from app import views
from app.views import RifiutiList, SegnalazioniList1

router = routers.DefaultRouter()
router.register(r'utente', views.UtenteViewSet)
router.register(r'tiporifiuto', views.TipoRifutoViewSet)
router.register(r'puntoraccolta', views.PuntoRaccoltaViewSet)
router.register(r'rifiuto', views.RifiutoViewSet)
router.register(r'puntocontrollo', views.PuntoControlloViewSet)
router.register(r'segnalazione', views.SegnalazioneViewSet)

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include(router.urls)),
    url('^rifiuti/(?P<id_utente>.+)/$', RifiutiList.as_view()),
    url('^signal/(?P<id_addetto>.+)/$', SegnalazioniList1.as_view()),
    path('api-auth/', include('rest_framework.urls', namespace='rest_framework')),
]
