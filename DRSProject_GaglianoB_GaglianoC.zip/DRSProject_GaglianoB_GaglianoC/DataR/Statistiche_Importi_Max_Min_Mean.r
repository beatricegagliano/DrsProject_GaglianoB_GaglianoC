> library("RSQLite")
Warning message:
package ‘RSQLite’ was built under R version 4.0.5 
> library("DBI")
Warning message:
package ‘DBI’ was built under R version 4.0.5 
> db=dbConnect(SQLite(),dbname="C:/Users/gagli/sqlite/db.sqlite3")
> db
<SQLiteConnection>
  Path: C:\Users\gagli\sqlite\db.sqlite3
  Extensions: TRUE
> dbListTables(db)
 [1] "app_puntocontrollo"         "app_puntoraccolta"          "app_rifiuto"                "app_segnalazione"          
 [5] "app_tiporifiuto"            "app_utente"                 "auth_group"                 "auth_group_permissions"    
 [9] "auth_permission"            "auth_user"                  "auth_user_groups"           "auth_user_user_permissions"
[13] "django_admin_log"           "django_content_type"        "django_migrations"          "django_session"            
[17] "sqlite_sequence"   
>importi=dbGetQuery(db,"select importo from app_segnalazione")
> importi
   importo
1    12.56
2    20.67
3    17.89
4    32.89
5    23.56
6    25.67
7    15.35
8    22.45
9    21.13
10   14.54
> meanImporto=mean(importi$importo, na.rm=TRUE)
> meanImporto
[1] 20.671
> maxImporto=max(importi$importo, na.rm=TRUE)
> maxImporto
[1] 32.89
> minImporto= min(importi$importo, na.rm=TRUE)
> minImporto
[1] 12.56
> importidataframe=data.frame(meanImporto,maxImporto,minImporto)
> importidataframe
  meanImporto maxImporto minImporto
1      20.671      32.89      12.56

> valori <- c(meanImporto,maxImporto,minImporto)
> etichette <- c("mean","max","min")
> pie(valori, labels = valori, main = "Grafico: media, max, min Importo delle segnalazioni", col = rainbow(length(valori)))
> legend("topright", etichette, cex = 0.8, fill = rainbow(length(valori)))
