> library("RSQLite")
Warning message:
package ‘RSQLite’ was built under R version 4.0.5 
> library("DBI")
Warning message:
package ‘DBI’ was built under R version 4.0.5 
> db=dbConnect(SQLite(),dbname="C:/Users/gagli/sqlite/db.sqlite3")
> db
<SQLiteConnection>
  Path: C:\Users\gagli\sqlite\db.sqlite3
  Extensions: TRUE
> dbListTables(db)
 [1] "app_puntocontrollo"         "app_puntoraccolta"          "app_rifiuto"                "app_segnalazione"          
 [5] "app_tiporifiuto"            "app_utente"                 "auth_group"                 "auth_group_permissions"    
 [9] "auth_permission"            "auth_user"                  "auth_user_groups"           "auth_user_user_permissions"
[13] "django_admin_log"           "django_content_type"        "django_migrations"          "django_session"            
[17] "sqlite_sequence"              
> TipiRifiuti=dbGetQuery(db,"select cod_tipo_rifiuto_id from app_rifiuto")
> TipiRifiuti
   cod_tipo_rifiuto_id
1                carta
2                carta
3                carta
4                carta
5                carta
6                carta
7      indifferenziata
8             organico
9             organico
10            organico
11            plastica
12            plastica
13            plastica
14            plastica
15            plastica
16            plastica
17            plastica
18               vetro
19               vetro
20               vetro

> str(TipiRifiuti)
'data.frame':   20 obs. of  1 variable:
 $ cod_tipo_rifiuto_id: chr  "carta" "carta" "carta" "carta" ...

> TipiRifiuti$cod_tipo_rifiuto_id <- factor(TipiRifiuti$cod_tipo_rifiuto_id)
> summary(TipiRifiuti$cod_tipo_rifiuto_id)
  carta indifferenziata        organico        plastica           vetro 
      6               1               3               7               3 

> colori<-terrain.colors(5)

> plot(TipiRifiuti$cod_tipo_rifiuto_id,beside=TRUE,col=colori,main = "Grafico:Statistiche sui tipi di rifiuti smaltiti")
