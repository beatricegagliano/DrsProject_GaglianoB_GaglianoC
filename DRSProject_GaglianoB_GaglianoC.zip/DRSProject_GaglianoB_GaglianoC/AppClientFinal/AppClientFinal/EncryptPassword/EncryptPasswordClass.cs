﻿using System;
using System.Security.Cryptography;
using System.Text;


namespace AppClientFinal.EncryptPassword
{
    public class EncryptPasswordClass
    {
        //crittografia password
        public static string Encrypt(string value)
        {
            using (SHA256 mySHA256 = SHA256.Create())
            {
                UTF8Encoding utf8 = new UTF8Encoding();
                byte[] hashValue = mySHA256.ComputeHash(utf8.GetBytes(value));
                return Convert.ToBase64String(hashValue);
            }
        }


    }
}
