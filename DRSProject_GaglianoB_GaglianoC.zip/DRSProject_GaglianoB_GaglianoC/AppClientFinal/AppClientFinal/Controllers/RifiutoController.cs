﻿using AppClientFinal.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;

namespace AppClientFinal.Controllers
{
    public class RifiutoController : Controller
    {
        
        public HttpClient client = new HttpClient();


        //Funzionalità WasteList che restituisce i rifiuti filtrati by username utente
        [HttpGet]

        public async Task<IActionResult> RifiutibyUser()
        {
            //recupero la variabile di sessione
            string id_utente = HttpContext.Session.GetString("UserID");
            string responseBody = await client.GetStringAsync("http://localhost:8000/rifiuti/"+id_utente+"/");
            //deserializzazione della stringa Json nella lista di tipo Rifiuto
            List<Rifiuto> message = JsonConvert.DeserializeObject<List<Rifiuto>>(responseBody);
            return View(message);
        }

        //Funzionalità SignalList che restituisce tutte le segnalazioni
        [HttpGet]
        public async Task<IActionResult> SignalAll()
        {
            string responseBody = await client.GetStringAsync("http://localhost:8000/segnalazione/");
            List<Segnalazione> message = JsonConvert.DeserializeObject<List<Segnalazione>>(responseBody);
            return View(message);
        }





    }

}
