﻿using Microsoft.AspNetCore.Mvc;


namespace AppClientFinal.Controllers
{
    public class InformationsController : Controller
    {
        //metodo About che restituisce la View About.cshtml associata
        public ActionResult About()
        {
            return View();
        }

        //metodo Contact che restituisce la View Contact.cshtml associata
        public ActionResult Contact()
        {
           
            return View();
        }


    }
}
