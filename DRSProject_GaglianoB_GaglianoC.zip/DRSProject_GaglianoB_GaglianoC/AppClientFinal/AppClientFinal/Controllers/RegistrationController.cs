﻿using AppClientFinal.EncryptPassword;
using AppClientFinal.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace AppClientFinal.Controllers
{
    public class RegistrationController : Controller
    {
        //Inizializza una nuova istanza di HttpClient per l'invio di richieste http e la ricezione di risposte http
        public HttpClient client = new HttpClient();
        
        
        public ActionResult Signin()
        {
            return View();
        }

        public ActionResult Error()
        {
            return View();
        }

        public ActionResult Login()
        {
            return View();
        }

       
        //Funzionalità Signin che consente la registrazione di un utente
        [HttpPost]
        public async Task<ActionResult> Signin(Utente credentials)
        {


            Utente userCredentials;

           

            if (credentials.Username != null & credentials.Password != null & credentials.Name != null & credentials.Surname != null & credentials.Email != null)
            {

                //crittografia della password invocando il metodo Encrypt che genera l'hash code per la stringa specificata
                string encryptedPassword = EncryptPasswordClass.Encrypt(credentials.Password);

                userCredentials = new Utente(credentials.Name, credentials.Surname, credentials.Email, credentials.Username, encryptedPassword,credentials.IsAdmin);
                var jsonInString = JsonConvert.SerializeObject(userCredentials);
                HttpResponseMessage response = await client.PostAsync("http://localhost:8000/utente/", new StringContent(jsonInString, Encoding.UTF8, "application/json"));
                response.EnsureSuccessStatusCode();
                string responseBody = await response.Content.ReadAsStringAsync();
                Console.WriteLine(responseBody);
                //settaggio della variabile di sessione allo username dell'utente 
                HttpContext.Session.SetString("UserID", credentials.Username);
                //controllo del booleano IsAdmin, se True si apre la control section
                if (credentials.IsAdmin)
                {
                    return RedirectToAction("Signal", "Segnalazione");
                }
                else return RedirectToAction("Index", "Home");

                }

            //Errore campi vuoti
            string msg = "Please ,enter all fields";
            TempData["Error"] = msg;
            return RedirectToAction("Error");

        }


        //Funzionalità login che consente l'autenticazione dell'utente tramite username e password
        [HttpPost]
        public async Task<ActionResult> Login(UtenteLogin credentials)
        {
           
            if (credentials.UsernameLogin != null & credentials.PasswordLogin != null)
            {
                string encryptedPassword = EncryptPasswordClass.Encrypt(credentials.PasswordLogin);

                string responseBody = await client.GetStringAsync("http://localhost:8000/utente/");
                //deserializzazione della stringa json in un dynamic object
                dynamic list = JsonConvert.DeserializeObject(responseBody);
                //Settaggio della variabile di sessione allo username dell'utente
                HttpContext.Session.SetString("UserID", credentials.UsernameLogin);
                //controllo che lo username e la password inseriti siano quelli di un utente già registrato
                foreach (var i in list)
                {
                    string j = i["username"];
                    string y = i["password"];
                    string user = credentials.UsernameLogin;

                    if (j.ToUpper().Contains(user.ToUpper()))
                    {

                        if (y.Contains(encryptedPassword))
                        {
                            if(credentials.IsAdmin)
                            {
                                return RedirectToAction("Signal","Segnalazione");
                            }
                            else return RedirectToAction("Index", "Home");

                        }
                    }

                    else ViewData["Error"] = "Please, enter correct credentials";

                }

            }


            ViewData["Error"] = "Please ,enter all fields";
            return RedirectToAction("Error");

        }





    }
}
