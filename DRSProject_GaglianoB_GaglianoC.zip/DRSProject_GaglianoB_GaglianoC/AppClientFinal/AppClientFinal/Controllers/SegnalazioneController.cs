﻿using AppClientFinal.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace AppClientFinal.Controllers
{
    public class SegnalazioneController : Controller
    {
        public HttpClient client = new HttpClient();
        public ActionResult Signal()
        {
            return View();
        }

        public ActionResult Error()
        {
            return View();
        }



        //Funzionalità Signal che consente all'admin di inserire una segnalazione
        [HttpPost]
        public async Task<ActionResult> Signal(Segnalazione segnalazione)
        {

            Segnalazione infosignal;

            if (segnalazione.Titolo != null & segnalazione.Descrizione != null & segnalazione.Importo != 0 & segnalazione.Cod_rifiuto != 0 & segnalazione.Cod_punto_controllo != null)
            {
                //recupero della variabile di sessione
                string id_addetto = HttpContext.Session.GetString("UserID");

                infosignal = new Segnalazione (segnalazione.Titolo, segnalazione.Descrizione, segnalazione.Importo, segnalazione.Cod_rifiuto, segnalazione.Cod_punto_controllo, id_addetto);
                //serializza l'oggetto Json in stringa
                var jsonInString = JsonConvert.SerializeObject(infosignal);
                HttpResponseMessage response = await client.PostAsync("http://localhost:8000/segnalazione/", new StringContent(jsonInString, Encoding.UTF8, "application/json"));
                response.EnsureSuccessStatusCode();
                string responseBody = await response.Content.ReadAsStringAsync();
                Console.WriteLine(responseBody);
                return RedirectToAction("Signal", "Segnalazione");
            }


            string msg = "Please ,enter all fields";
            TempData["Error"] = msg;
            return RedirectToAction("Error");


        }

        //Funzionalità SignalList che restituisce tutte le segnalazioni filtrate per id_addetto
        [HttpGet]

        public async Task<IActionResult> SignalList()
        {

            string id_addetto = HttpContext.Session.GetString("UserID");
            string responseBody = await client.GetStringAsync("http://localhost:8000/signal/" + id_addetto + "/");
            List<Segnalazione> message = JsonConvert.DeserializeObject<List<Segnalazione>>(responseBody);
            return View(message);
        }

        //Funzionalità WasteList che restituisce tutti i rifiuti inseriti
        [HttpGet]

        public async Task<IActionResult> Index()
        {

            string responseBody = await client.GetStringAsync("http://localhost:8000/rifiuto/");
            List<Rifiuto> message = JsonConvert.DeserializeObject<List<Rifiuto>>(responseBody);
            return View(message);
        }




    }
}
