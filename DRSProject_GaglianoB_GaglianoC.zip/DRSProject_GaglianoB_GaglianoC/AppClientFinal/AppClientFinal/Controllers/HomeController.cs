﻿using AppClientFinal.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace AppClientFinal.Controllers
{
    public class HomeController : Controller
    {


        public HttpClient client = new HttpClient();

     //metoto Index che ritorna la View Index.cshtml associata
        public ActionResult Index()
        {
            return View();
        }

        //metodo Error che ritorna la View Error.cshtml associata
        public ActionResult Error()
        {
            return View();
        }

        //Logout che cancella i dati della sessione tramite HttpContext.Session.Clear()
        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Login", "Registration");
        }


        //Funzionalità della Home: Post di un nuovo rifiuto all'endpoint specificato
        [HttpPost]
        public async Task<ActionResult> Index(Rifiuto rifiuto)
        {


            Rifiuto rifiutoInfo;


            if (rifiuto.Cod_punto_raccolta != null & rifiuto.Cod_tipo_rifiuto != null)
            {
                string id_utente = HttpContext.Session.GetString("UserID");
                rifiutoInfo = new Rifiuto(rifiuto.Cod_punto_raccolta, rifiuto.Cod_tipo_rifiuto, id_utente);
                var jsonInString = JsonConvert.SerializeObject(rifiutoInfo);
                HttpResponseMessage response = await client.PostAsync("http://localhost:8000/rifiuto/", new StringContent(jsonInString, Encoding.UTF8, "application/json"));
                response.EnsureSuccessStatusCode();
                string responseBody = await response.Content.ReadAsStringAsync();
                Console.WriteLine(responseBody);



                return RedirectToAction("Index", "Home");
            }


            string msg = "Please ,enter all fields";
            TempData["Error"] = msg;
            return RedirectToAction("Error");


        }






    }
}
