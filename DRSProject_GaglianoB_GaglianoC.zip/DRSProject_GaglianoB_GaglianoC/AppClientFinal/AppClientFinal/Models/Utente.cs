﻿using Newtonsoft.Json;
using System;


namespace AppClientFinal.Models
{
    public class Utente
    {
        public Utente()
        {
        }

        public int Id { get; set; }

        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("surname")]
        public string Surname { get; set; }

        [JsonProperty("email")]
        public string Email { get; set; }

        [JsonProperty("username")]
        public string Username { get; set; }


        [JsonProperty("password")]
        public string Password { get; set; }

        [JsonProperty("isAdmin")]
        public bool IsAdmin { get; set; }





        public Utente(string name, string surname, string email, string username, string password,bool isadmin)
        {
            this.Name = name ?? throw new ArgumentNullException(nameof(name));
            this.Surname = surname ?? throw new ArgumentNullException(nameof(surname));
            this.Email = email ?? throw new ArgumentNullException(nameof(email));
            this.Username = username ?? throw new ArgumentNullException(nameof(username));
            this.Password = password ?? throw new ArgumentNullException(nameof(password));
            this.IsAdmin = isadmin;
        }




    }
}
