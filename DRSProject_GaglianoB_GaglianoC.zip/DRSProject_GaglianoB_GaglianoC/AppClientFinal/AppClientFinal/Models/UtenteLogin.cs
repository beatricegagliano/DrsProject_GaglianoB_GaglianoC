﻿using Newtonsoft.Json;
using System;


namespace AppClientFinal.Models
{
    public class UtenteLogin
    {
        public UtenteLogin()
        {
        }
        public int Id { get; set; }
        [JsonProperty("username")]
        public string UsernameLogin { get; set; }


        [JsonProperty("password")]
        public string PasswordLogin { get; set; }


        [JsonProperty("isAdmin")]
        public bool IsAdmin { get; set; }

        public UtenteLogin(string usernameLogin, string passwordLogin, bool isadmin)
        {
            this.UsernameLogin = usernameLogin ?? throw new ArgumentNullException(nameof(usernameLogin));
            this.PasswordLogin = passwordLogin ?? throw new ArgumentNullException(nameof(passwordLogin));
            this.IsAdmin = isadmin;
        }



    }
}
