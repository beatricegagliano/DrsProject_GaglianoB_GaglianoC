﻿using Newtonsoft.Json;
using System;


namespace AppClientFinal.Models
{
    public class PuntoRaccolta
    {
        public PuntoRaccolta()
        {
        }

        public int id { get; set; }

        [JsonProperty("name")]
        public string Point { get; set; }

        [JsonProperty("address")]
        public string Address { get; set; }

        public PuntoRaccolta(string name, string address)
        {
            this.Point = name ?? throw new ArgumentNullException(nameof(name));
            this.Address = address ?? throw new ArgumentNullException(nameof(address));
        }

    }
}
