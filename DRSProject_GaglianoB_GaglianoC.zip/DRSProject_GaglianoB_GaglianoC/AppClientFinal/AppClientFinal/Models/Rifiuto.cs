﻿using Newtonsoft.Json;


namespace AppClientFinal.Models
{
    public class Rifiuto
    {

        public int Id { get; set; }

        [JsonProperty("cod_punto_raccolta")]
        public string Cod_punto_raccolta { get; set; }

        [JsonProperty("cod_tipo_rifiuto")]
        public string Cod_tipo_rifiuto { get; set; }

        [JsonProperty("id_utente")]
        public string Id_utente { get; set; }

        public Rifiuto()
        {

        }


        public Rifiuto(string pr, string tr, string ut)
        {
            this.Cod_punto_raccolta = pr;
            this.Cod_tipo_rifiuto = tr;
            this.Id_utente = ut;
        }
    }



}










