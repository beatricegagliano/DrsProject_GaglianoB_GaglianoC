﻿using Newtonsoft.Json;
using System;


namespace AppClientFinal.Models
{
    public class Segnalazione
    {

        public Segnalazione() { }
        public int Id { get; set; }

        [JsonProperty("titolo")]
        public string Titolo { get; set; }

        [JsonProperty("descrizione")]
        public string Descrizione { get; set; }

        [JsonProperty("importo")]
        public float Importo { get; set; }

        [JsonProperty("cod_rifiuto")]
        public int Cod_rifiuto { get; set; }

        [JsonProperty("cod_punto_controllo")]
        public string Cod_punto_controllo { get; set; }

        [JsonProperty("id_addetto")]
        public string Id_addetto { get; set; }


        public Segnalazione(string titolo, string descrizione, float importo, int cod_rifiuto, string cod_punto_controllo, string id_addetto)
        {
            this.Titolo = titolo ?? throw new ArgumentNullException(nameof(titolo));
            this.Descrizione = descrizione ?? throw new ArgumentNullException(nameof(descrizione));
            this.Importo = importo;
            this.Cod_rifiuto = cod_rifiuto;
            this.Cod_punto_controllo = cod_punto_controllo ?? throw new ArgumentNullException(nameof(cod_punto_controllo));
            this.Id_addetto = id_addetto;
        }


    }
}
