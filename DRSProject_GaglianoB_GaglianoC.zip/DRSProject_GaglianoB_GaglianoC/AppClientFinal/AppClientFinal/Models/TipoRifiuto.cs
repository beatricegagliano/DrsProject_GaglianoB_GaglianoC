﻿using Newtonsoft.Json;
using System;


namespace AppClientFinal.Models
{
    public class TipoRifiuto
    {


        public TipoRifiuto()
        {
        }

        public int Id { get; set; }

        [JsonProperty("name")]
        public string Name { get; set; }

        public TipoRifiuto(string name)
        {
            this.Name = name ?? throw new ArgumentNullException(nameof(name));

        }





    }
}
